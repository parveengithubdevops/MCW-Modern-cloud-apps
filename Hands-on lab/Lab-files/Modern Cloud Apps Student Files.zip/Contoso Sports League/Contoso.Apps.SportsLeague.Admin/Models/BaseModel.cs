﻿namespace Contoso.Apps.SportsLeague.Admin.Models
{
    public class BaseModel
    {
        public string DisplayName { get; set; }
    }
}