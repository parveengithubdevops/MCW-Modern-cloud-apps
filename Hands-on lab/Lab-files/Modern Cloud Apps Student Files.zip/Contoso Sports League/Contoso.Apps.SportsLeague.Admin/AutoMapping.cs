﻿using AutoMapper;
using Contoso.Apps.SportsLeague.Data.Models;
using System.Collections.Generic;

namespace Contoso.Apps.SportsLeague.Admin
{
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {
            
        }
    }

}
